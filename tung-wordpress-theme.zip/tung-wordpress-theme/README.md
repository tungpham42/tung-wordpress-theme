# Tung Pham's Homework for WordPress Engineer position at CBTW

## Demo: [https://cbtw.soft.io.vn/](https://cbtw.soft.io.vn/)

## Login URL: [https://cbtw.soft.io.vn/wp-admin/](https://cbtw.soft.io.vn/wp-admin/)

## Account: cbtw , Password: !30eQb3emXaZnUxa!t9^SfLI
